/**
 * Created by abhishekrathore on 12/29/16.
 */
(function () {
    'use strict';

    angular.module('starter')

        .controller('menuCtrl', function ($state, $cordovaNetwork, $cordovaToast, $ionicLoading) {
            var menu = this;

        })
})();
